export const pathToUploadedAvatars = 'public/avatars';
export const pathToUploadedInvoices = 'public/invoices-files';
