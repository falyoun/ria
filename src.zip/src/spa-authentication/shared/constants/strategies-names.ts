export const StrategiesNames = {
  ITE_JWT: 'ite-jwt',
  ITE_WS_JWT: 'ite-ws-jwt',
};
