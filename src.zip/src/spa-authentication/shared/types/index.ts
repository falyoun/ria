export * from './spa-auth-options.type';
export * from './cookie-object.type';
export type IPayload = string | Buffer | object;
