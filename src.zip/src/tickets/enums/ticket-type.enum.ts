export enum TicketTypeEnum {
  CHANGE_PASSWORD = 'change_password',
}
