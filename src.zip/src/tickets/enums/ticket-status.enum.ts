export enum TicketStatusEnum {
  OPEN = 'open',
  CLOSED = 'closed',
  REJECTED = 'rejected',
  DONE = 'done',
}
