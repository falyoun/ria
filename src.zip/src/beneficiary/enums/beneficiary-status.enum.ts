export enum BeneficiaryStatus {
  INACTIVE = 'inactive',
  IN_PROGRESS = 'in_progress',
  APPROVED = 'approved',
}
