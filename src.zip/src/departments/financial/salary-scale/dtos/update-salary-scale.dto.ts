export class UpdateSalaryScaleDto {}
