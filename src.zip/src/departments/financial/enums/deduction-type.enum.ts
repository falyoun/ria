export enum DeductionTypeEnum {
  LOAN = 'loan',
  TAX = 'tax',
  ATTENDANCE = 'attendance',
}
