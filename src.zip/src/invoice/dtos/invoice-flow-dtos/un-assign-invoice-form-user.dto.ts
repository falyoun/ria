import { AssignInvoiceToUserDto } from '@app/invoice/dtos/invoice-flow-dtos/assign-invoice-to-user.dto';

export class UnAssignInvoiceFormUserDto extends AssignInvoiceToUserDto {}
