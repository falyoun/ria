export class ApproveInvoiceDto {}
