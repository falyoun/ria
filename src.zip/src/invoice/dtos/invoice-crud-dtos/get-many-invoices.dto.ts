import { SequelizePaginationDto } from '@app/shared/dtos/sequelize-pagination.dto';

export class GetManyInvoicesDto extends SequelizePaginationDto {}
