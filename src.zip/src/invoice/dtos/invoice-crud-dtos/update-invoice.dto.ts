import { CreateInvoiceDto } from '@app/invoice/dtos/invoice-crud-dtos/create-invoice.dto';

export class UpdateInvoiceDto extends CreateInvoiceDto {}
