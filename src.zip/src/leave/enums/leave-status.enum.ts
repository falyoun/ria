export enum LeaveStatusEnum {
  REJECTED = 'rejected',
  APPROVED = 'approved',
  PENDING_APPROVAL = 'pending_approval',
}
